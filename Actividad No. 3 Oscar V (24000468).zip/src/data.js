// data.js

const tasks = [];
const goals = [];

module.exports = { tasks, goals };

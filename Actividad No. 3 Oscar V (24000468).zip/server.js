// server.js

const express = require('express');
const { tasks, goals } = require('./data');
const app = express();
const PORT = 3000;
const API_KEY = 'mi-apikey-secreta';

app.use(express.json());

// Middleware para verificar la API key
app.use((req, res, next) => {
    const apiKey = req.headers['authorization'];
    if (apiKey === API_KEY) {
        next();
    } else {
        res.status(403).json({ message: 'No autorizado' });
    }
});

// Obtener tareas
app.get('/getTasks', (req, res) => {
    res.json(tasks);
});

// Obtener metas
app.get('/getGoals', (req, res) => {
    res.json(goals);
});

// Agregar tarea
app.post('/addTask', (req, res) => {
    const { name, deadline } = req.body;
    if (name && deadline) {
        tasks.push({ name, deadline });
        res.json({ message: 'Tarea agregada' });
    } else {
        res.status(400).json({ message: 'Datos incompletos' });
    }
});

// Agregar meta
app.post('/addGoal', (req, res) => {
    const { name, deadline } = req.body;
    if (name && deadline) {
        goals.push({ name, deadline });
        res.json({ message: 'Meta agregada' });
    } else {
        res.status(400).json({ message: 'Datos incompletos' });
    }
});

// Eliminar tarea
app.delete('/removeTask', (req, res) => {
    const { name } = req.body;
    const index = tasks.findIndex(task => task.name === name);
    if (index !== -1) {
        tasks.splice(index, 1);
        res.json({ message: 'Tarea eliminada' });
    } else {
        res.status(404).json({ message: 'Tarea no encontrada' });
    }
});

// Eliminar meta
app.delete('/removeGoal', (req, res) => {
    const { name } = req.body;
    const index = goals.findIndex(goal => goal.name === name);
    if (index !== -1) {
        goals.splice(index, 1);
        res.json({ message: 'Meta eliminada' });
    } else {
        res.status(404).json({ message: 'Meta no encontrada' });
    }
});

// Iniciar el servidor
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});

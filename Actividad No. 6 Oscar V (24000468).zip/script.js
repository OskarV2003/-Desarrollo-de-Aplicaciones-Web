// src/actions/types.js
export const FETCH_GOALS    = 'FETCH_GOALS';
export const ADD_GOAL       = 'ADD_GOAL';
export const REMOVE_GOAL    = 'REMOVE_GOAL';
export const GOALS_ERROR    = 'GOALS_ERROR';

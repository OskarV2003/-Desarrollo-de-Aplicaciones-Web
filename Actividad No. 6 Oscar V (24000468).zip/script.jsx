// src/components/GoalForm.js
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addGoal } from '../actions/goalActions';

export default function GoalForm() {
  const [title, setTitle] = useState('');
  const [dueDate, setDueDate] = useState('');
  const dispatch = useDispatch();

  const onSubmit = e => {
    e.preventDefault();
    dispatch(addGoal({ title, dueDate }));
    setTitle('');
    setDueDate('');
  };

  return (
    <form onSubmit={onSubmit}>
      <input 
        value={title} 
        onChange={e => setTitle(e.target.value)} 
        placeholder="Título de la meta" 
        required 
      />
      <input 
        type="date"
        value={dueDate} 
        onChange={e => setDueDate(e.target.value)} 
        required 
      />
      <button type="submit">Agregar Meta</button>
    </form>
  );
}

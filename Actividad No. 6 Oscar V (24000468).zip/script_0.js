// src/actions/goalActions.js
import axios from 'axios';
import { FETCH_GOALS, ADD_GOAL, REMOVE_GOAL, GOALS_ERROR } from './types';

const API_BASE = '/api';

// Obtener todas las metas
export const fetchGoals = () => async dispatch => {
  try {
    const res = await axios.get(`${API_BASE}/getGoals`);
    dispatch({ type: FETCH_GOALS, payload: res.data });
  } catch (err) {
    dispatch({ type: GOALS_ERROR, payload: err.message });
  }
};

// Agregar meta
export const addGoal = goalData => async dispatch => {
  try {
    const res = await axios.post(`${API_BASE}/addGoal`, goalData);
    // el payload es la nueva meta (incluye _id que devuelve Mongo)
    dispatch({ type: ADD_GOAL, payload: res.data });
  } catch (err) {
    dispatch({ type: GOALS_ERROR, payload: err.message });
  }
};

// Eliminar meta
export const removeGoal = id => async dispatch => {
  try {
    await axios.delete(`${API_BASE}/removeGoal/${id}`);
    dispatch({ type: REMOVE_GOAL, payload: id });
  } catch (err) {
    dispatch({ type: GOALS_ERROR, payload: err.message });
  }
};

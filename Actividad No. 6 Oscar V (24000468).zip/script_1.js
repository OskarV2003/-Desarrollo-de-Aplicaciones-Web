// src/reducers/goalsReducer.js
import { FETCH_GOALS, ADD_GOAL, REMOVE_GOAL, GOALS_ERROR } from '../actions/types';

const initialState = {
  items: [],    // lista de metas
  error: null
};

export default function goalsReducer(state = initialState, action) {
  switch (action.type) {
    case FETCH_GOALS:
      return { ...state, items: action.payload, error: null };

    case ADD_GOAL:
      return { 
        ...state, 
        items: [...state.items, action.payload],
        error: null 
      };

    case REMOVE_GOAL:
      return { 
        ...state, 
        items: state.items.filter(goal => goal._id !== action.payload),
        error: null 
      };

    case GOALS_ERROR:
      return { ...state, error: action.payload };

    default:
      return state;
  }
}

// src/reducers/index.js
import { combineReducers } from 'redux';
import goalsReducer from './goalsReducer';
// (podrías agregar taskReducer aquí también)
export default combineReducers({
  goals: goalsReducer
});

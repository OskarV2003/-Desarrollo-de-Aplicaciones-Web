// src/components/GoalsList.js
import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { fetchGoals, removeGoal } from '../actions/goalActions';

export default function GoalsList() {
  const { items, error } = useSelector(state => state.goals);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(fetchGoals());
  }, [dispatch]);

  if (error) return <p>Error: {error}</p>;

  return (
    <ul>
      {items.map(g => (
        <li key={g._id}>
          {g.title} — {new Date(g.dueDate).toLocaleDateString()}
          <button onClick={() => dispatch(removeGoal(g._id))}>Eliminar</button>
        </li>
      ))}
    </ul>
  );
}

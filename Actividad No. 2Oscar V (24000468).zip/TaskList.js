import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { deleteTask } from './tasksSlice';

const TaskList = () => {
  const tasks = useSelector(state => state.tasks);
  const dispatch = useDispatch();

  return (
    <ul>
      {tasks.map(task => (
        <li key={task.id}>
          <strong>{task.title}</strong> - Límite: {task.deadline}
          <button onClick={() => dispatch(deleteTask(task.id))}>Eliminar</button>
        </li>
      ))}
    </ul>
  );
};

export default TaskList;

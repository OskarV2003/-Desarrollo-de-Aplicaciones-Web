import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addTask } from '../features/tasks/tasksSlice';
import { v4 as uuidv4 } from 'uuid';

const TaskForm = () => {
  const [title, setTitle] = useState('');
  const [deadline, setDeadline] = useState('');
  const dispatch = useDispatch();

  const handleSubmit = e => {
    e.preventDefault();
    if (!title) return;

    dispatch(addTask({
      id: uuidv4(),
      title,
      deadline
    }));

    setTitle('');
    setDeadline('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        placeholder="Escribe una tarea..."
        value={title}
        onChange={e => setTitle(e.target.value)}
      />
      <input
        type="date"
        value={deadline}
        onChange={e => setDeadline(e.target.value)}
      />
      <button type="submit">Agregar</button>
    </form>
  );
};

export default TaskForm;

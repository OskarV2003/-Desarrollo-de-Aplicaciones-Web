import React from 'react';
import TaskForm from './components/TaskForm';
import TaskList from './features/tasks/TaskList';

function App() {
  return (
    <div>
      <h1>To Do List con Redux</h1>
      <TaskForm />
      <TaskList />
    </div>
  );
}

export default App;

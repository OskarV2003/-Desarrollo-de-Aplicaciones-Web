import React from "react";
import { ListGroup, Badge } from "react-bootstrap";

function TaskList() {
  return (
    <ListGroup>
      <ListGroup.Item className="d-flex justify-content-between align-items-center">
        Terminar maqueta HTML
        <Badge bg="secondary">2025-04-25</Badge>
      </ListGroup.Item>
      <ListGroup.Item className="d-flex justify-content-between align-items-center">
        Subir a GitHub
        <Badge bg="secondary">2025-04-26</Badge>
      </ListGroup.Item>
    </ListGroup>
  );
}

export default TaskList;

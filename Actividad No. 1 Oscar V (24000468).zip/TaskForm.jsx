import React from "react";
import { Form, Button } from "react-bootstrap";

function TaskForm() {
  return (
    <Form>
      <Form.Group controlId="formTask">
        <Form.Label>Tarea</Form.Label>
        <Form.Control type="text" placeholder="Ej. Leer 10 páginas del libro" />
      </Form.Group>

      <Form.Group controlId="formDeadline" className="mt-3">
        <Form.Label>Fecha límite</Form.Label>
        <Form.Control type="date" />
      </Form.Group>

      <Button variant="primary" type="submit" className="mt-4">
        Agregar Tarea
      </Button>
    </Form>
  );
}

export default TaskForm;
